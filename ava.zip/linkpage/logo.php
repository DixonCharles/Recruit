<a href="./" class="navbar-brand">
    <img src="assets/img/logo-w-2.png" alt="Logo" width="auto" height="85%">
</a>