<section class="" style="background:#f4f9f5;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="contact-from">
                        <div class="pt-45" style="padding: 8px 0px;">
                            <form id="contact-form" action="contact" method="post" data-toggle="validator">
                                <div class="row">
                                    
                                    <div class="col-md-12">
                                        <hr>
                                        <div class="singel-form wow fadeInUp" style="text-align: center; margin-top:-5px;">
                                            <span class="mai-document-text"></span> <a href="download.php?file=Ava-Care-Terms-Conditions" class="text-blue" style="text-decoration:none;">Terms & Conditions</a>
                                        </div> <!-- singel form -->
                                    </div> 

                                </div> <!-- row -->
                            </form>
                        </div> <!-- main form -->
                    </div> <!--  contact from -->
                </div>

            </div> <!-- row -->
        </div> <!-- container -->
    </section>