  <footer class="page-footer">
    <div class="container">
      <div class="row px-md-3">

        <div class="col-sm-6 col-lg-12 py-3">
          <form id="contact-form" method="post" data-toggle="validator">
                                <div class="row">
                                    
                                    <div class="col-lg-12">
                                      <?php

                                            if (isset($_POST['send'])) {
                                                                                     
                                                $to = 'info@avacarers.com';
                                                $subject = 'Getting In Touch With Ava Care';
                                                $from = $_POST['email'];
                                                $fromName = $_POST['fullName'];
                                                $tel = $_POST['phone'];
                                                $message = $_POST['message'];
                                                
                                                // Email body content 
                                                $htmlContent = ' 
                                                    <p style="font-size:17px;"><b>Name:</b> '.$fromName.'</p> 
                                                    <p style="font-size:17px;"><b>Email:</b> '.$email.'</p> 
                                                    <p style="font-size:17px;"><b>Telephone:</b> '.$tel.'</p> 
                                                    <p style="font-size:17px;"><b>Message:</b> '.$message.'</p> 
                                                '; 
                                                 
                                                // Header for sender info 
                                                $headers = "From: $fromName"." <".$from.">"; 
                                                 
                                                // Boundary  
                                                $semi_rand = md5(time());  
                                                $mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";  
                                                 
                                                // Headers for attachment  
                                                $headers .= "\nMIME-Version: 1.0\n" . "Content-Type: multipart/mixed;\n" . " boundary=\"{$mime_boundary}\""; 
                                                 
                                                // Multipart boundary  
                                                $message = "--{$mime_boundary}\n" . "Content-Type: text/html; charset=\"UTF-8\"\n" . 
                                                "Content-Transfer-Encoding: 7bit\n\n" . $htmlContent . "\n\n";  


                                                $message .= "--{$mime_boundary}--"; 
                                                $returnpath = "-f" . $from; 
                                                 

                                                // Sending email
                                                if(@mail($to, $subject, $message, $headers, $returnpath)){
                                                    echo '<p style="text-align:center; background:#f0f8fd; margin-top:10px; padding:10px; border-radius:4px;" class="text-blue bg-bluish">Dear '.$fromName.', your request was sent seccessfully, we will respond shortly.</p>';
                                                } else{
                                                    echo '<p style="text-align:center; margin-top:10px; padding:10px; border-radius:4px; color:#c4160a; background:#ffe5e3;" class="">Unable to send request now. Please try again.</p>';
                                                }

                                            }
                                        ?>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="singel-form form-group">
                                            <h5 style="margin-bottom:5px;">Request A Call Back Service</h5>
                                            <div class="bg-pink" style="width:40px; height: 3px; margin-bottom: 15px;"></div>
                                        </div> <!-- singel form -->
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="singel-form form-group" style="margin-bottom:10px;">
                                            <input class="form-control" name="fullName" type="text" placeholder="Full Name" data-error="Name is required." required="required">
                                            <div class="help-block with-errors"></div>
                                        </div> <!-- singel form -->
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="singel-form form-group" style="margin-bottom:10px;">
                                            <input class="form-control" name="address" type="text" placeholder="Address" data-error="Address is required." required="required">
                                            <div class="help-block with-errors"></div>
                                        </div> <!-- singel form -->
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="singel-form form-group" style="margin-bottom:10px;">
                                            <input class="form-control" name="tel" type="tel" placeholder="Telephone" data-error="Valid email is required." required="required">
                                            <div class="help-block with-errors"></div>
                                        </div> <!-- singel form -->
                                    </div>

                                    <div class="col-md-12">
                                        <div class="singel-form" style="margin-bottom:10px; text-align: right;">
                                            <button type="submit" name="send" class="btn bg-blue text-white" style="margin-bottom:20px;">Send</button>
                                        </div> <!-- singel form -->
                                    </div> 
                                </div> <!-- row -->
                            </form>
        </div>
        <div class="col-sm-12">
          <span class="mai-document-text"></span> <a href="download.php?file=Ava-Care-Terms-Conditions" class="text-white" style="text-decoration:none;">Terms & Conditions</a>
        </div>
      </div>
      <hr>
      <div class="row px-md-3">
        <div class="col-sm-6 col-lg-4 py-3">
          <div class="logo">
              <a href="./"><img src="assets/img/logo-w-1.png" alt="Logo" width="90%" height="auto" style="text-align:left;"></a>
          </div>
          <p class="footer-link mt-2">The centre is focused in provision of good and accurate services with high quality</p>
          <div class="footer-sosmed mt-3">
            <a href="#" target="_blank"><span class="mai-logo-facebook-f"></span></a>
            <a href="#" target="_blank"><span class="mai-logo-instagram"></span></a>
            <a href="#" target="_blank"><span class="mai-logo-linkedin"></span></a>
          </div>
                        
        </div>
        <div class="col-sm-6 col-lg-1 py-3">
        </div>
        <div class="col-sm-6 col-lg-2 py-3">
          <h5 class="text-white">Quick Links</h5>
          <ul class="footer-menu">
            <li><a href="about">About Us</a></li>
            <li><a href="services">Our Services</a></li>
            <li><a href="appy">Apply</a></li>
            <li><a href="contact">Contact us</a></li>
          </ul>
        </div>
        <div class="col-sm-6 col-lg-5 py-3">
          <h5 class="text-white">Contact</h5>

          
          <div class="cont" style="padding-top: 10px;">
              <div style="width:20px; color: rgba(255, 255, 255, 0.6); position: absolute; padding-top: 2px;">
                  <span class="mai-location" style="margin-right: 10px; font-size:18px;"></span>
              </div>
              <div style="width:auto; margin-left:40px; color: rgba(255, 255, 255, 0.6);">
                  <span class="mt-2">11 Salcey Street, Northampton NN4 8NY, UK</span>
              </div>
          </div>
          <div class="cont" style="padding-top: 10px;">
              <div style="width:20px; color: rgba(255, 255, 255, 0.6); position: absolute; padding-top: 2px;">
                  <span class="mai-call" style="margin-right: 10px; font-size:18px;"></span>
              </div>
              <div style="width:auto; margin-left:40px;">
                  <a href="tel:+447450399039" class="mt-2" style="color: rgba(255, 255, 255, 0.6); text-decoration:none;"> +44 7450 399039</a>
              </div>
          </div>
          <div class="cont" style="padding-top: 10px;">
              <div style="width:20px; color: rgba(255, 255, 255, 0.6); position: absolute; padding-top: 2px;">
                  <span class="mai-mail" style="margin-right: 10px; font-size:18px;"></span>
              </div>
              <div style="width:auto; margin-left:40px;">
                  <a href="mailto:info@avacarers.co.uk" class="mt-2" style="color: rgba(255, 255, 255, 0.6); text-decoration:none;"> info@avacarers.com</a>
              </div>
          </div>
        </div>

      </div>

      <hr>

      <p class="text-white" id="copyright">Copyright &copy; <script>document.write(new Date().getFullYear())</script> Ava Care Recruitment, All Rights Reserved. <span style="color: silver;">Designed By <a href="https://eldigital.co.tz" target="blank" style="text-decoration: none; color: silver;">elDigital</a></span></p>
    </div>
  </footer>